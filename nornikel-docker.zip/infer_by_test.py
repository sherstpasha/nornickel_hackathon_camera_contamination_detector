import os
import sys
import json
import base64
import cv2
import numpy as np
from ultralytics import YOLO

# Программа получает на вход два аргумента: путь к датасету и путь к выходному файлу
dataset_path, output_path = sys.argv[1:]

# Функция инференса модели
def infer_image(model, image_path):
    image = cv2.imread(image_path)
    return model(image, conf=0.33)

# Укажите корректный путь до вашей модели, которая будет находиться в проекте
model_path = './baseline.pt'
example_model = YOLO(model_path)
example_model.to('cpu')

def create_mask(image_path, results):
    # Загружаем изображение и определяем размеры
    image = cv2.imread(image_path)
    height, width = image.shape[:2]

    # Итоговая маска
    final_mask = np.zeros((height, width), dtype=np.uint8)

    # Проходим по результатам
    for result in results:
        masks = result.masks
        if masks is not None:
            for mask_array in masks.data:
                mask_i = mask_array.numpy()

                # Изменяем размер маски под изображение
                mask_i_resized = cv2.resize(mask_i, (width, height), interpolation=cv2.INTER_LINEAR)
                bin_mask = (mask_i_resized > 0).astype(np.uint8)

                # Находим контуры в бинарной маске
                contours, _ = cv2.findContours(bin_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                for contour in contours:
                    # Находим центр контура для масштабирования
                    M = cv2.moments(contour)
                    if M["m00"] != 0:
                        cx = M["m10"] / M["m00"]
                        cy = M["m01"] / M["m00"]
                    else:
                        x, y, w, h = cv2.boundingRect(contour)
                        cx = x + w / 2
                        cy = y + h / 2

                    # Переносим контур к центру, масштабируем и возвращаем обратно
                    contour = contour.astype(np.float32)
                    contour[:, 0, 0] -= cx
                    contour[:, 0, 1] -= cy
                    contour = contour * 1.1  # Увеличиваем на 10%
                    contour[:, 0, 0] += cx
                    contour[:, 0, 1] += cy

                    # Сглаживаем контур
                    epsilon = 0.01 * cv2.arcLength(contour, True)
                    smoothed_contour = cv2.approxPolyDP(contour, epsilon, True)

                    # Рисуем сглаженные и увеличенные контуры на итоговой маске
                    cv2.drawContours(final_mask, [smoothed_contour.astype(int)], -1, 255, thickness=cv2.FILLED)

    return final_mask

# Словарь для накопления результатов
results_dict = {}

# Производим инференс для каждого изображения и сохраняем маски в один JSON файл
for image_name in os.listdir(dataset_path):
    if image_name.lower().endswith(".jpg"):
        results = infer_image(example_model, os.path.join(dataset_path, image_name))
        mask = create_mask(os.path.join(dataset_path, image_name), results)
        
        # Кодируем маску в PNG в память
        _, encoded_img = cv2.imencode(".png", mask)
        # Кодируем в base64, чтобы поместить в JSON
        encoded_str = base64.b64encode(encoded_img).decode('utf-8')
        results_dict[image_name] = encoded_str

# Сохраняем результаты в один файл "submit" (формат JSON)
with open(output_path, "w", encoding="utf-8") as f:
    json.dump(results_dict, f, ensure_ascii=False)
